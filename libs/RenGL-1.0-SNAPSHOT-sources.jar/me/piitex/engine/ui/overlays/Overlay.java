package me.piitex.engine.ui.overlays;

import me.piitex.engine.ui.Element;

public abstract class Overlay extends Element {
}
